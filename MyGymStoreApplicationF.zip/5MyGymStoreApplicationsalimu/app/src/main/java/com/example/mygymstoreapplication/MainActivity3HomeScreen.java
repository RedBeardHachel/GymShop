package com.example.mygymstoreapplication;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ToggleButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;

public class MainActivity3HomeScreen extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    Button btnWheyP, btnL, btnMap, btnCall, btnWhatsapp, btnSms, btnCustom;
    ToggleButton btntogglem;
    ImageButton btnCart;
    Dialog dialog;
    String PersonName;
    ArrayList<WheyProduct> userlist;
    boolean wheytrue = true;
   private final static int REQUEST_CODE=100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity3_home_screen);

        PersonName = getIntent().getStringExtra("PersonName");
        btnMap = findViewById(R.id.btnMap);
        btnWheyP = findViewById(R.id.btnWheyP);
        btnL = findViewById(R.id.btnL);
        btnCart = findViewById(R.id.btnCart);
        btntogglem = findViewById(R.id.btntogglem);
        btntogglem.setOnCheckedChangeListener(this);
        btnWheyP.setOnClickListener(this);
        btnMap.setOnClickListener(this);
        btnL.setOnClickListener(this);
        btnCart.setOnClickListener(this);

        btnCustom = findViewById(R.id.btnCustom);
        btnCustom.setOnClickListener(this);
        userlist = new ArrayList<>();


        ActivityCompat.requestPermissions(MainActivity3HomeScreen.this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ShowMap();

            }
        });



    }
    private void ShowMap(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            Intent i = new Intent(MainActivity3HomeScreen.this, MapsActivity1.class);
            startActivity(i);
        }else{
            GetPremission();
        }

    }

    private void GetPremission(){
        ActivityCompat.requestPermissions(MainActivity3HomeScreen.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode==REQUEST_CODE){
            if(grantResults.length > 0 &&  grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                ShowMap();
            }
            else
            {
                Toast.makeText(MainActivity3HomeScreen.this, "provide the required permission", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    public void sendSMS(View view){

        String message = "Hello,can you help me please?";
        String number = "+972545482527";

        SmsManager mySmsManager = SmsManager.getDefault();
        mySmsManager.sendTextMessage(number,null, message, null, null);
        dialog.dismiss();
        Toast.makeText(this,"you will get help soon",Toast.LENGTH_LONG).show();
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onClick(View view) {
        if (view == btnWheyP) {

            Intent i = new Intent(MainActivity3HomeScreen.this, MainActivity4WheyList.class);
            i.putExtra("PersonName",PersonName);
            i.putExtra("isWhey",wheytrue);
            startActivity(i);

        }
        if (view==btnL){

            Intent i = new Intent(MainActivity3HomeScreen.this, MainActivity.class);
            startActivity(i);

        }

        if(view == btnCustom){
            dialog = new Dialog(this);//יצירת אובייקט דו-שיח
            dialog.setCancelable(true);//לא ניתן לבטל עם esc
            dialog.setContentView(R.layout.custom_layout);//להשתמש בחלון xml custom_layout
            btnCall = dialog.findViewById(R.id.btnCall);//מפעילים חיפוש בתוך dialog
            btnWhatsapp = dialog.findViewById(R.id.btnWhatsapp);
            btnSms=dialog.findViewById(R.id.btnSms);
            btnSms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sendSMS(v);
                }
            });
            btnWhatsapp.setOnClickListener(this);
            btnCall.setOnClickListener(this);
            dialog.show();

        }else if(btnCall==view) {
            dialog.dismiss();
            Toast.makeText(this,"ok",Toast.LENGTH_LONG).show();
            Uri number = Uri.parse("tel:+972544697768");
            Intent callIntent = new Intent(Intent.ACTION_DIAL, number);
            startActivity(callIntent);

        }
        else if(btnWhatsapp==view){
            Intent i= new Intent(Intent.ACTION_VIEW,Uri.parse("https://api.whatsapp.com/send?phone=972545482527"));
            Toast.makeText(this,"Moving to Whatsapp",Toast.LENGTH_LONG).show();
            startActivity(i);

        }else if (btnCart==view){
            wheytrue=false;
            LoadUserListFromDatabase();
        }



    }



    private void LoadUserListFromDatabase()
    {

        userlist.clear();
        DatabaseReference database = FirebaseDatabase.getInstance().getReference("Customers").child(PersonName).child("ShoppingList");
        database.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>()
        {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task)
            {

                if(task.isSuccessful() && task.getResult().exists()){
                    DataSnapshot dataSnapshot=task.getResult();
                    for (DataSnapshot currProduct:dataSnapshot.getChildren()){
                        WheyProduct product;
                        if (currProduct.getKey().toString().equals("Protein Powder")){
                            product=new ProteinPowder();
                        }else  if (currProduct.getKey().toString().equals("Creatine")){
                            product=new Creatine();

                        }else  if (currProduct.getKey().toString().equals("Gainer")){
                            product=new Gainer();

                        }else  if (currProduct.getKey().toString().equals("Protein Bar")){
                            product=new ProteinBar();

                        }else  if (currProduct.getKey().toString().equals("Protein Shake")){
                            product=new ProteinShake();

                        }else
                        {
                            product=new WheySnack();
                        }
                        for (DataSnapshot currProductElements:currProduct.getChildren()){
                            if(currProductElements.getKey().toString().equals("Amount")){
                                product.setAmount(Integer.valueOf(currProductElements.getValue().toString()));

                            }else if(currProductElements.getKey().toString().equals("Company")){
                                product.setCompany(currProductElements.getValue().toString());

                            }else if(currProductElements.getKey().toString().equals("Cosher")){
                                product.setCosher(currProductElements.getValue().toString());

                            }else if(currProductElements.getKey().toString().equals("ExpiryDate")){
                                product.setExpirydate(currProductElements.getValue().toString());

                            }else if(currProductElements.getKey().toString().equals("Name")){
                                product.setName(currProductElements.getValue().toString());

                            }else if(currProductElements.getKey().toString().equals("Weight")){
                                product.setWeight(Double.valueOf(currProductElements.getValue().toString()));

                            }else if(currProductElements.getKey().toString().equals("Price")){
                                product.setPrice(Integer.valueOf(currProductElements.getValue().toString()));

                            }
                        }
                        userlist.add(product);
                    }

                            Intent i = new Intent(MainActivity3HomeScreen.this, userlist.class);
                            i.putExtra("PersonName", PersonName);
                            i.putExtra("ProductList", userlist);
                            i.putExtra("isWhey", wheytrue);
                            startActivity(i);

                }
                //
                Intent i = new Intent(MainActivity3HomeScreen.this, userlist.class);
                i.putExtra("PersonName", PersonName);
                i.putExtra("ProductList", userlist);
                i.putExtra("isWhey", wheytrue);
                startActivity(i);
//

            }


        });

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId())
        {
            case R.id.btntogglem:
                if (isChecked){
                    Intent intent = new Intent(this,MyService.class);
                    stopService(intent);
                }else {
                    Intent intent = new Intent(this,MyService.class);
                    startService(intent);
                }
        }
    }
}
