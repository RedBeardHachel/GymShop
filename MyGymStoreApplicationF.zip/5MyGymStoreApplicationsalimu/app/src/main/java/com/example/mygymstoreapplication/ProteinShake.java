package com.example.mygymstoreapplication;

public class ProteinShake extends WheyProduct {


    public ProteinShake() {
        super("Protein Shake", 30, 0.75, "R1", "Dairy", "19/10/2022",0);

    }
}
