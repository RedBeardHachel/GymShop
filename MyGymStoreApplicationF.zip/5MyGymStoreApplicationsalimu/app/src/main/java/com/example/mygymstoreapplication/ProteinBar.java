package com.example.mygymstoreapplication;

public class ProteinBar extends WheyProduct {

    public ProteinBar() {

        super("ProteinBar", 15, 0.2, "R1", "Dairy", "19/10/2022",0);
    }

}