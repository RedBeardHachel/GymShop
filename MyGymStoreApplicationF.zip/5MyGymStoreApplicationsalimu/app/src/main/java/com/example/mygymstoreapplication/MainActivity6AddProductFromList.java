package com.example.mygymstoreapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity6AddProductFromList extends AppCompatActivity implements View.OnClickListener {
    int minteger = 0,save6sum_all=0;
    TextView etprice,txtInfo,displayInteger;
    ImageButton ibtnAdd,ibtnBack;
    WheyProduct currProduct1;
    String PersonName;
    private ArrayList<WheyProduct> userlist;
    boolean wheytrue;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity6_add_product_from_list);
        PersonName=getIntent().getStringExtra("PersonName");
        currProduct1=(WheyProduct)getIntent().getSerializableExtra("Product1");
        userlist=(ArrayList<WheyProduct>)getIntent().getSerializableExtra("ProductList");
        wheytrue=getIntent().getBooleanExtra("isWhey",true);
        userlist=new ArrayList<WheyProduct>();
        etprice=(TextView) findViewById(R.id.etPrice);
        txtInfo=(TextView) findViewById(R.id.txtInfo);
        displayInteger = (TextView) findViewById(R.id.integer_number);
        ibtnBack=findViewById(R.id.ibtnBack);
        ibtnBack.setOnClickListener(this);
        ibtnAdd=findViewById(R.id.ibtnAdd);
        ibtnAdd.setOnClickListener(this);
        txtInfo.setText("Name: "+currProduct1.getName()+"\n"+"Price per unit: "+currProduct1.getPrice()+"\n"+"Weight per unit: "+currProduct1.getWeight()+"\n"+"Company: "+currProduct1.getCompany()+"\n"+"Cosher: "+currProduct1.getCosher()+"\n"+"ExpiryDate: "+currProduct1.getExpirydate());

    }

    public void increaseInteger(View view) {
        if (minteger<100)
        minteger = minteger + 1;
        display(minteger);

    }

    public void decreaseInteger(View view) {
        if(minteger>=1)
        minteger = minteger - 1;
        display(minteger);
    }

    private void display(int number) {

            displayInteger.setText("" + number);
            etprice.setText("Price: " + number * currProduct1.getPrice() + " ");
        }

    public void takeAllPricesFromFireBase() {
        DatabaseReference _ref = FirebaseDatabase.getInstance().getReference("Customers").child(PersonName).child("ShoppingList");
        _ref.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {

                    if (task.getResult().exists()) {
                        DataSnapshot snapshot = task.getResult();
                        for (DataSnapshot snap : snapshot.getChildren()) {

                            if (snap.hasChild("TotalPrice")) {

                                save6sum_all += Integer.parseInt(snap.child("TotalPrice").getValue().toString());
                            }

                        }

                    }


                }

            }

        });


    }

    private void AddToCart() {
        int amount = Integer.valueOf(displayInteger.getText().toString());


        DatabaseReference _ref = FirebaseDatabase.getInstance().getReference("Customers").child(PersonName);
        _ref.child("ShoppingList").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if(task.isSuccessful())
                {
                    boolean add = true;
                    if (task.getResult().exists())
                    {
                        DataSnapshot snapshot = task.getResult();
                        if(snapshot.hasChild(currProduct1.getName()))
                        {

                            add = false;
                            for(DataSnapshot snap:snapshot.getChildren()){
                                if (snap.getKey().equals(currProduct1.getName())){
                                    HashMap<String,Object> productmap=new HashMap<>();
                                    productmap.put("Amount", amount);
                                    productmap.put("TotalPrice", currProduct1.getPrice() * amount);
                                    productmap.put("TotalWeight", currProduct1.getWeight() * amount);


                                    if (amount!=0)
                                    {
                                        FirebaseDatabase.getInstance().getReference().child("Customers").child(PersonName).child("ShoppingList").child(currProduct1.getName()).updateChildren(productmap);
                                    }else{
                                       DatabaseReference databaseReference =  FirebaseDatabase.getInstance().getReference().child("Customers").child(PersonName).child("ShoppingList").child(currProduct1.getName());
                                       databaseReference.removeValue();
                                    }
                                }
                            }
                        }
                    }
                    if(add)
                    {
                        if (amount!=0) {
                            HashMap<String, Object> productInfoMap = new HashMap<>();
                            productInfoMap.put("Name", currProduct1.getName());
                            productInfoMap.put("Amount", amount);
                            productInfoMap.put("Weight", currProduct1.getWeight());
                            productInfoMap.put("Price", currProduct1.getPrice());
                            productInfoMap.put("TotalPrice", currProduct1.getPrice() * amount);
                            productInfoMap.put("TotalWeight", currProduct1.getWeight() * amount);
                            productInfoMap.put("Company", currProduct1.getCompany());
                            productInfoMap.put("Cosher", currProduct1.getCosher());
                            productInfoMap.put("ExpiryDate", currProduct1.getExpirydate());

                            FirebaseDatabase.getInstance().getReference().child("Customers").child(PersonName).child("ShoppingList").child(currProduct1.getName()).updateChildren(productInfoMap);
                        }else{
                            Toast.makeText(MainActivity6AddProductFromList.this,"Cannot create for null object",Toast.LENGTH_LONG).show();
                        }

                    }


                }
            }
        });


    }

    private void LoadUserListFromDatabase()
    {


        DatabaseReference database = FirebaseDatabase.getInstance().getReference("Customers").child(PersonName).child("ShoppingList");
        database.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {

                if (task.isSuccessful()) {
                    if (task.getResult().exists()) {
                        DataSnapshot dataSnapshot = task.getResult();
                        for (DataSnapshot currProduct : dataSnapshot.getChildren()) {
                            WheyProduct product;
                            if (currProduct.getKey().toString().equals("Protein Powder")) {
                                product = new ProteinPowder();
                            } else if (currProduct.getKey().toString().equals("Creatine")) {
                                product = new Creatine();

                            } else if (currProduct.getKey().toString().equals("Gainer")) {
                                product = new Gainer();

                            } else if (currProduct.getKey().toString().equals("Protein Bar")) {
                                product = new ProteinBar();

                            } else if (currProduct.getKey().toString().equals("Protein Shake")) {
                                product = new ProteinShake();

                            } else {
                                product = new WheySnack();
                            }
                            for (DataSnapshot currProductElements : currProduct.getChildren()) {
                                if (currProductElements.getKey().toString().equals("Amount")) {
                                    product.setAmount(Integer.valueOf(currProductElements.getValue().toString()));

                                } else if (currProductElements.getKey().toString().equals("Company")) {
                                    product.setCompany(currProductElements.getValue().toString());

                                } else if (currProductElements.getKey().toString().equals("Cosher")) {
                                    product.setCosher(currProductElements.getValue().toString());

                                } else if (currProductElements.getKey().toString().equals("ExpiryDate")) {
                                    product.setExpirydate(currProductElements.getValue().toString());

                                } else if (currProductElements.getKey().toString().equals("Name")) {
                                    product.setName(currProductElements.getValue().toString());

                                } else if (currProductElements.getKey().toString().equals("Weight")) {
                                    product.setWeight(Double.valueOf(currProductElements.getValue().toString()));

                                } else if (currProductElements.getKey().toString().equals("Price")) {
                                    product.setPrice(Integer.valueOf(currProductElements.getValue().toString()));

                                }
                            }
                            userlist.add(product);
                            takeAllPricesFromFireBase();
                        }
                        if (!wheytrue) {
                            Intent i = new Intent(MainActivity6AddProductFromList.this, userlist.class);
                            i.putExtra("PersonName", PersonName);
                            i.putExtra("ProductList", userlist);
                            i.putExtra("Product1", currProduct1);
                            i.putExtra("MY_KEY", save6sum_all);

                            startActivity(i);
                        }
                    }
//
                    Intent i = new Intent(MainActivity6AddProductFromList.this, userlist.class);
                    i.putExtra("PersonName", PersonName);
                    i.putExtra("ProductList", userlist);
                    i.putExtra("Product1", currProduct1);
                    i.putExtra("MY_KEY", save6sum_all);

                    startActivity(i);
//
                }
            }
        });

    }

    @Override
    public void onClick(View view) {
        if (view==ibtnBack && wheytrue){
            Intent i = new Intent(MainActivity6AddProductFromList.this, MainActivity4WheyList.class);
            i.putExtra("PersonName", PersonName);
            i.putExtra("ProductList", userlist);
            startActivity(i);
        } else if(view==ibtnBack && !wheytrue) {
            LoadUserListFromDatabase();
        }


        if (view==ibtnAdd){
            AddToCart();
            Toast.makeText(MainActivity6AddProductFromList.this, "Succeed",
                    Toast.LENGTH_LONG).show();

        }

    }
}