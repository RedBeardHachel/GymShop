package com.example.mygymstoreapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.nightonke.boommenu.BoomButtons.ButtonPlaceEnum;
import com.nightonke.boommenu.BoomButtons.OnBMClickListener;
import com.nightonke.boommenu.BoomButtons.TextOutsideCircleButton;
import com.nightonke.boommenu.BoomMenuButton;
import com.nightonke.boommenu.ButtonEnum;
import com.nightonke.boommenu.Piece.PiecePlaceEnum;
import java.util.ArrayList;

public class MainActivity4WheyList extends AppCompatActivity implements View.OnClickListener {
Button btn4P1,btn4P2,btn4P3,btn4P4,btn4P6,btn4P7,btnBackToHome;
String PersonName;
boolean wheytrue;
ArrayList<WheyProduct> userlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity4_whey_list);
        PersonName=getIntent().getStringExtra("PersonName");
        wheytrue=getIntent().getBooleanExtra("isWhey",true);
        btn4P1 = findViewById(R.id.btn4P1);
        btn4P1.setOnClickListener(this);
        btn4P2 = findViewById(R.id.btn4P2);
        btn4P2.setOnClickListener(this);
        btn4P3 = findViewById(R.id.btn4P3);
        btn4P3.setOnClickListener(this);
        btn4P4 = findViewById(R.id.btn4P4);
        btn4P4.setOnClickListener(this);
        btn4P6 = findViewById(R.id.btn4P6);
        btn4P6.setOnClickListener(this);
        btn4P7 = findViewById(R.id.btn4P7);
        btn4P7.setOnClickListener(this);
        btnBackToHome = findViewById(R.id.btnBackToHome);
        btnBackToHome.setOnClickListener(this);

        userlist = new ArrayList<>();

        int[] imageResources = new int[2];
        imageResources[0] = R.drawable.shoppingbag;
        imageResources[1] = R.drawable.logout;

        String[] imageResources2 = new String[2];
        imageResources2[0] ="Go to your cart";
        imageResources2[1] = "Logout";


        BoomMenuButton bmb=findViewById(R.id.bmb);
        bmb.setButtonEnum(ButtonEnum.TextOutsideCircle);
        bmb.setPiecePlaceEnum(PiecePlaceEnum.DOT_2_1);
        bmb.setButtonPlaceEnum(ButtonPlaceEnum.SC_2_1);
        bmb.setDraggable(true);

        for (int i=0;i<bmb.getButtonPlaceEnum().buttonNumber();i++){
            bmb.addBuilder(new TextOutsideCircleButton.Builder().normalImageRes(imageResources[i]).normalText(imageResources2[i]).listener(new OnBMClickListener() {
                @Override
                public void onBoomButtonClick(int index) {
                    buttonClicked(index);
                }
            }));

        }

    }

    private void buttonClicked(int index) {
        if (index==0){
            wheytrue=false;
            LoadUserListFromDatabase();


        }
        if (index==1){
            Intent i = new Intent(MainActivity4WheyList.this, MainActivity.class);
            startActivity(i);
            Intent intent = new Intent(this,MyService.class);
            stopService(intent);
        }

    }

    private void LoadUserListFromDatabase() {
        userlist.clear();
        DatabaseReference database = FirebaseDatabase.getInstance().getReference("Customers").child(PersonName).child("ShoppingList");
        database.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>()
        {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task)
            {

                if(task.isSuccessful() && task.getResult().exists()){
                    DataSnapshot dataSnapshot=task.getResult();
                    for (DataSnapshot currProduct:dataSnapshot.getChildren()){
                        WheyProduct product;
                        if (currProduct.getKey().toString().equals("Protein Powder")){
                            product=new ProteinPowder();
                        }else  if (currProduct.getKey().toString().equals("Creatine")){
                            product=new Creatine();

                        }else  if (currProduct.getKey().toString().equals("Gainer")){
                            product=new Gainer();

                        }else  if (currProduct.getKey().toString().equals("Protein Bar")){
                            product=new ProteinBar();

                        }else  if (currProduct.getKey().toString().equals("Protein Shake")){
                            product=new ProteinShake();

                        }else  //if (currProduct.getKey().toString().equals("WheySnack"))
                        {
                            product=new WheySnack();
                        }
                        for (DataSnapshot currProductElements:currProduct.getChildren()){
                            if(currProductElements.getKey().toString().equals("Amount")){
                                product.setAmount(Integer.valueOf(currProductElements.getValue().toString()));

                            }else if(currProductElements.getKey().toString().equals("Company")){
                                product.setCompany(currProductElements.getValue().toString());

                            }else if(currProductElements.getKey().toString().equals("Cosher")){
                                product.setCosher(currProductElements.getValue().toString());

                            }else if(currProductElements.getKey().toString().equals("ExpiryDate")){
                                product.setExpirydate(currProductElements.getValue().toString());

                            }else if(currProductElements.getKey().toString().equals("Name")){
                                product.setName(currProductElements.getValue().toString());

                            }else if(currProductElements.getKey().toString().equals("Weight")){
                                product.setWeight(Double.valueOf(currProductElements.getValue().toString()));

                            }else if(currProductElements.getKey().toString().equals("Price")){
                                product.setPrice(Integer.valueOf(currProductElements.getValue().toString()));

                            }
                        }
                        userlist.add(product);
                    }
                    Intent i = new Intent(MainActivity4WheyList.this, userlist.class);
                    i.putExtra("PersonName", PersonName);
                    i.putExtra("ProductList", userlist);
                    i.putExtra("isWhey",wheytrue);
                    startActivity(i);
                }
                //
                Intent i = new Intent(MainActivity4WheyList.this, userlist.class);
                i.putExtra("PersonName", PersonName);
                i.putExtra("ProductList", userlist);
                i.putExtra("isWhey",wheytrue);
                startActivity(i);
                //
            }


        });

    }

    @Override
    public void onClick(View view) {
        if (view == btn4P1) {
            WheyProduct product=new ProteinPowder();
            Intent i = new Intent(MainActivity4WheyList.this, MainActivity6AddProductFromList.class);
            i.putExtra("Product1",product);
            i.putExtra("PersonName",PersonName);
            i.putExtra("isWhey",wheytrue);
            startActivity(i);

        }
       else if (view == btn4P2) {
            WheyProduct product=new Creatine();
            Intent i = new Intent(MainActivity4WheyList.this, MainActivity6AddProductFromList.class);
            i.putExtra("Product1",product);
            i.putExtra("PersonName",PersonName);
            i.putExtra("isWhey",wheytrue);
            startActivity(i);



        }
        else if (view == btn4P3) {
            WheyProduct product=new WheySnack();
            Intent i = new Intent(MainActivity4WheyList.this, MainActivity6AddProductFromList.class);
            i.putExtra("Product1",product);
            i.putExtra("PersonName",PersonName);
            i.putExtra("isWhey",wheytrue);
            startActivity(i);



        }
        else if (view == btn4P4) {
            WheyProduct product=new Gainer();
            Intent i = new Intent(MainActivity4WheyList.this, MainActivity6AddProductFromList.class);
            i.putExtra("Product1",product);
            i.putExtra("PersonName",PersonName);
            i.putExtra("isWhey",wheytrue);
            startActivity(i);



        }
        else if (view == btn4P6) {
            WheyProduct product=new ProteinBar();
            Intent i = new Intent(MainActivity4WheyList.this, MainActivity6AddProductFromList.class);
            i.putExtra("Product1",product);
            i.putExtra("PersonName",PersonName);
            i.putExtra("isWhey",wheytrue);
            startActivity(i);


        }
        else if (view == btn4P7) {
            WheyProduct product=new ProteinShake();
            Intent i = new Intent(MainActivity4WheyList.this, MainActivity6AddProductFromList.class);
            i.putExtra("Product1",product);
            i.putExtra("PersonName",PersonName);
            i.putExtra("isWhey",wheytrue);
            startActivity(i);



        }

        if (view==btnBackToHome){
            Intent i = new Intent(MainActivity4WheyList.this, MainActivity3HomeScreen.class);
            i.putExtra("PersonName",PersonName);
            startActivity(i);
        }

    }
}