package com.example.mygymstoreapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;

public class userlist extends AppCompatActivity implements View.OnClickListener {
    private String PersonName;
    private RecyclerView recyclerView;
    private SelectAProductAdapter adapter;
    private ArrayList<WheyProduct> userlist;
    Button btnLO ,btnBuy,_btnCancel2;
    Dialog dialog;
    TextView _txtMessage,txtsumprice;
    boolean wheytrue;
    int sum_all,save6sum_all;
    WheyProduct currProduct1,save_curr_p;
    MyReceiverBattery myReceiverBattery = new MyReceiverBattery();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlist);
        PersonName=getIntent().getStringExtra("PersonName");
        currProduct1=(WheyProduct)getIntent().getSerializableExtra("Product1");
        userlist=new ArrayList<>();
        userlist=(ArrayList<WheyProduct>)getIntent().getSerializableExtra("ProductList");
        wheytrue=getIntent().getBooleanExtra("isWhey",false);
        recyclerView = findViewById(R.id.userList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        txtsumprice=findViewById(R.id.txtsumprice);
        save6sum_all=getIntent().getExtras().getInt("MY_KEY");
        btnLO=findViewById(R.id.btnLO);
        btnLO.setOnClickListener(this);
        btnBuy=findViewById(R.id.btnBuy);
        btnBuy.setOnClickListener(this);


        adapter=new SelectAProductAdapter(this,userlist);
        recyclerView.setAdapter(adapter);
        takeAllPricesFromFireBase();


    }

    public void takeAllPricesFromFireBase() {
        DatabaseReference _ref = FirebaseDatabase.getInstance().getReference("Customers").child(PersonName).child("ShoppingList");
        _ref.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {

                    if (task.getResult().exists()) {
                        DataSnapshot snapshot = task.getResult();
                            for (DataSnapshot snap : snapshot.getChildren()) {

                                if (snap.hasChild("TotalPrice")) {

                                    sum_all += (save6sum_all+Integer.parseInt(snap.child("TotalPrice").getValue().toString()));
                                }

                            }

                        }
                    txtsumprice.setText("Total Price: "+sum_all+ "");

                    }

                }

            });


        }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(myReceiverBattery,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));


    }

    @Override
    public void onClick(View view) {
        if (view == btnLO) {
            Intent i = new Intent(userlist.this, MainActivity3HomeScreen.class);
            i.putExtra("PersonName", PersonName);
            startActivity(i);

        }
        if (view == btnBuy) {
            if (MyReceiverBattery.battery < 10) {
                Toast.makeText(this, "Unable to pay, battery is too low", Toast.LENGTH_LONG).show();
            } else{
                dialog = new Dialog(this);//יצירת אובייקט דו-שיח
                dialog.setCancelable(false);//לא ניתן לבטל עם esc
                dialog.setContentView(R.layout.activity_main_payment_screen);//להשתמש בחלון xml custom_layout
                _txtMessage = dialog.findViewById(R.id.txtMessage);
                _txtMessage.setMovementMethod(LinkMovementMethod.getInstance());
                _btnCancel2 = dialog.findViewById(R.id.btnCancel2);

                _btnCancel2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                        Toast.makeText(com.example.mygymstoreapplication.userlist.this, "canceled", Toast.LENGTH_LONG).show();
                    }
                });
                dialog.show();


            }


        }

    }



    private class SelectAProductAdapter extends RecyclerView.Adapter<SelectAProductAdapter.ProViewHolder>  {
        Context _context;
        ArrayList<WheyProduct>  _list;

        public SelectAProductAdapter(Context context, ArrayList<WheyProduct> list) {
            _context = context;
            _list = list;
        }


        @NonNull
        @Override
        public ProViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(_context).inflate(R.layout.item, parent, false);
            return new ProViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ProViewHolder holder, int position) {
            WheyProduct currProduct=_list.get(position);
            save_curr_p=currProduct;

            holder.name.setText(currProduct.getName());
            holder.price.setText(String.valueOf(currProduct.getPrice()));
            holder.weight.setText(String.valueOf(currProduct.getWeight()));
            holder.company.setText(currProduct.getCompany());
            holder.cosher.setText(currProduct.getCosher());
            holder.expirydate.setText(currProduct.getExpirydate());
            holder.amount.setText(String.valueOf(currProduct.getAmount()));
        }



        @Override
        public int getItemCount() {return _list.size();}

        public class ProViewHolder extends RecyclerView.ViewHolder{
            TextView name, price, weight, company,cosher,expirydate,amount;

            public ProViewHolder(@NonNull View itemView)
            {
                super(itemView);

                this.name = itemView.findViewById(R.id.tvName);
                this.price = itemView.findViewById(R.id.tvPrice);
                this.weight = itemView.findViewById(R.id.tvWeight);
                this.company = itemView.findViewById(R.id.tvCompany);
                this.cosher = itemView.findViewById(R.id.tvCosher);
                this.expirydate = itemView.findViewById(R.id.tvExpiryDate);
                this.amount=itemView.findViewById(R.id.tvAmount);


                itemView.findViewById(R.id.btnUpdate).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatabaseReference database = FirebaseDatabase.getInstance().getReference("Customers").child(PersonName).child("ShoppingList").child(name.getText().toString());
                        database.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                if (task.isSuccessful()) {

                                    if (task.getResult().exists()) {

                                        DataSnapshot dbUser = task.getResult();
                                        int dbAmount = Integer.parseInt(dbUser.child("Amount").getValue().toString());
                                        String dbCompany = dbUser.child("Company").getValue().toString();
                                        String dbCosher = dbUser.child("Cosher").getValue().toString();
                                        String dbExpiryDate = dbUser.child("ExpiryDate").getValue().toString();
                                        String dbName = dbUser.child("Name").getValue().toString();
                                        int dbPrice = Integer.parseInt(dbUser.child("Price").getValue().toString());
                                        Double dbWeight = Double.parseDouble(dbUser.child("Weight").getValue().toString());


                                        WheyProduct currProduct2 = new WheyProduct(dbName, dbPrice, dbWeight, dbCompany, dbCosher, dbExpiryDate, dbAmount);


                                        Intent i = new Intent(userlist.this, MainActivity6AddProductFromList.class);
                                        i.putExtra("PersonName", PersonName);
                                        i.putExtra("Product1", currProduct2);
                                        i.putExtra("ProductList",userlist);
                                        i.putExtra("isWhey",wheytrue);
                                        takeAllPricesFromFireBase();
                                        finish();
                                        startActivity(i);




                                    }
                                }
                            }
                        });
                    }


                });
            }
        }
    }
}
