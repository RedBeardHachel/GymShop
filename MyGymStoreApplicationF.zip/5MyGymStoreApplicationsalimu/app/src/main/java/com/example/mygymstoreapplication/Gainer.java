package com.example.mygymstoreapplication;

public class Gainer extends WheyProduct {

    public Gainer() {

        super("Gainer", 100, 3, "R1", "Parve", "19/10/2022",0);
    }

}