package com.example.mygymstoreapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnLogin,btnRegister;
    EditText etU,etP;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);
        etU=findViewById(R.id.etU);
        etP=findViewById(R.id.etP);
        btnLogin.setOnClickListener(view ->
        {

            connectUser();


        });

    }

    private void connectUser(){
        String username = etU.getText().toString();
        String pass = etP.getText().toString();

        if (TextUtils.isEmpty(username))
        {
            etU.setError("Username cannot be empty!");
            etU.requestFocus();
        }
        else if (TextUtils.isEmpty(pass))
        {
            etP.setError("Password cannot be empty!");
            etP.requestFocus();
        }
        else
        {
            DatabaseReference _ref = FirebaseDatabase.getInstance().getReference("Customers");
            _ref.child(username).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task)
                {
                    if(task.isSuccessful())
                    {
                        //user exist
                        if(task.getResult().exists())
                        {
                            DataSnapshot db_user = task.getResult();//the user
                            String db_password = db_user.child("Password").getValue().toString();

                            if(db_password.equals(pass))
                            {
                                //user exist
                                Intent i=new Intent(MainActivity.this, MainActivity3HomeScreen.class);
                                i.putExtra("PersonName",username);
                                startActivity(i);

                            }
                            else
                            {
                                etP.setError("Wrong password or user is not exist");
                                etP.requestFocus();
                            }
                        }

                    }


                }
            });

        }
    }

    @Override
    public void onClick(View v) {

        if (v==btnRegister){

            startActivity(new Intent(MainActivity.this, MainActivity2Register.class));
        }

    }
}
