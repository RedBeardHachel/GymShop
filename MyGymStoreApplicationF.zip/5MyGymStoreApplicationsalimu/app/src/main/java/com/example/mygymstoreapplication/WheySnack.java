package com.example.mygymstoreapplication;

public class WheySnack extends WheyProduct{

    public WheySnack() {
        super("Whey Snack", 20, 0.1, "All in", "Parve", "19/10/2022",0);
    }

}
