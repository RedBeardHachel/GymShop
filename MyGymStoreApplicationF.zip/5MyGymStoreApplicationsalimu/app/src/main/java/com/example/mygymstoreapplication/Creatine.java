package com.example.mygymstoreapplication;

public class Creatine extends WheyProduct {

    public Creatine() {

        super("Creatine", 80, 5, "R1", "Parve", "19/10/2022",0) ;
    }

}
