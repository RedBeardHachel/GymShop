package com.example.mygymstoreapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivityWelcome extends AppCompatActivity {
    ImageView ivgympho;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_welcome);
        ivgympho=findViewById(R.id.ivgympho);
        new Thread((Runnable)()-> {
                try {
                    synchronized (this){
                        ivgympho.animate().scaleX(900f).scaleY(900f).rotation(3600).setDuration(4000);
                        wait(4000);
                        Intent intent=new Intent(MainActivityWelcome.this,MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(intent);
                        finish();
                    }
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
        }).start();
        Intent intent = new Intent(this,MyService.class);
        startService(intent);
    }
}