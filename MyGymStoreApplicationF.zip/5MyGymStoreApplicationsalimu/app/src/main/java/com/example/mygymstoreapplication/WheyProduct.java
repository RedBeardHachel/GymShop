package com.example.mygymstoreapplication;

import java.io.Serializable;

public class WheyProduct implements Serializable {
    private String name;
    private int price;
    private double weight;
    private String company;
    private String cosher;
    private String expirydate;
    private int amount;



    public WheyProduct(String name, int price, double weight, String company, String cosher, String expirydate,int amount) {
        this.name = name;
        this.price = price;
        this.weight = weight;
        this.company = company;
        this.cosher = cosher;
        this.expirydate = expirydate;
        this.amount=amount;

    }



        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getPrice() {
            return price;
        }

        public void setPrice(int price) {
            this.price = price;
        }

        public double getWeight() {
            return weight;
        }

        public void setWeight(double weight) {
            this.weight = weight;
        }

        public String getCompany() {
            return company;
        }

        public void setCompany(String company) {
            this.company = company;
        }

        public String getCosher() {
            return cosher;
        }

        public void setCosher(String cosher) {
            this.cosher = cosher;
        }

        public String getExpirydate() {
            return expirydate;
        }

        public void setExpirydate(String expirydate) {
            this.expirydate = expirydate;
        }

        public int getAmount() {
            return amount;
        }

        public void setAmount(int amount) {
            this.amount = amount;
        }
}


