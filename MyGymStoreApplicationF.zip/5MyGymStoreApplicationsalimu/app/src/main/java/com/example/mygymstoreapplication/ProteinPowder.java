package com.example.mygymstoreapplication;

public class ProteinPowder extends WheyProduct{


    public ProteinPowder(){
        super("Protein Powder",170,10.2,"R1","Dairy","19/10/2022",0);

    }


}
