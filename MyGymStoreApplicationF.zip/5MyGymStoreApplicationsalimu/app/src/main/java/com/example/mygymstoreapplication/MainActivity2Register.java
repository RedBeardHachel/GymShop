package com.example.mygymstoreapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class MainActivity2Register extends AppCompatActivity implements View.OnClickListener {
    Button btnLoginFR, btnLoginFR2, btnChange,btnBack;
    EditText ete, etp, etp2, etPersonName, etPersonName2, etcp, etcp2;
    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity2_register);
        btnLoginFR = findViewById(R.id.btnLoginFR);
        ete = findViewById(R.id.ete);
        etcp = findViewById(R.id.etcp);
        etPersonName = findViewById(R.id.etPersonName);
        etp = findViewById(R.id.etp);
        btnChange = findViewById(R.id.btnChange);
        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);
        btnChange.setOnClickListener(this);
        btnLoginFR.setOnClickListener(view ->
        {
            createUser();
        });

    }

    private boolean validatePersonName(String firstName) {
        if (firstName.isEmpty()) {
            etPersonName.setError("Field cannot be empty");
            return false;
        } else if (firstName.length() >= 15) {
            etPersonName.setError("First name too long");
            return false;
        } else if (firstName.contains(" ")) {
            etPersonName.setError("White Spaces are not allowed");
            return false;
        } else {
            etPersonName.setError(null);
            return true;
        }
    }

    private boolean validatePassword(String password) {
        String passwordVal = "^" +
                "(?=.*[0-9])" +  //at least 1 digit
                "(?=.*[a-zA-z])" +  //at least 1 english letter
                "(?=\\S+$)" +  //no white spaces
                ".{8,}" +  //at least 8 characters
                "$";

        if (password.isEmpty()) {
            etp.setError("Field cannot be empty");
            return false;
        } else if (!password.matches(passwordVal)) {
            etp.setError("Password is too weak,at least 1 digit,at least 1 english letter,no white spaces,at least 8 characters");
            return false;
        } else if (!password.equals(etcp.getText().toString())) {
            etcp.setError("Passwords does not match");
            return false;
        } else {
            etp.setError(null);
            return true;
        }
    }

    private boolean validateEmail(String email) {
        String emailPattern = "[a-zA-z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (email.isEmpty()) {
            ete.setError("Field cannot be empty");
            return false;
        } else if (!email.matches(emailPattern)) {
            ete.setError("Invalid email address");
            return false;
        } else {
            ete.setError(null);
            return true;
        }
    }

    private boolean validatePersonName2(String firstName) {
        if (firstName.isEmpty()) {
            etPersonName2.setError("Field cannot be empty");
            return false;
        } else if (firstName.length() >= 15) {
            etPersonName2.setError("First name too long");
            return false;
        } else if (firstName.contains(" ")) {
            etPersonName2.setError("White Spaces are not allowed");
            return false;
        } else {
            etPersonName2.setError(null);
            return true;
        }
    }

    private boolean validatePassword2(String password) {
        String passwordVal = "^" +
                "(?=.*[0-9])" +  //at least 1 digit
                "(?=.*[a-zA-z])" +  //at least 1 english letter
                "(?=\\S+$)" +  //no white spaces
                ".{8,}" +  //at least 4 characters
                "$";

        if (password.isEmpty()) {
            etp2.setError("Field cannot be empty");
            return false;
        } else if (!password.matches(passwordVal)) {
            etp2.setError("Password is too weak");
            return false;
        } else if (!password.equals(etcp2.getText().toString())) {
            etcp2.setError("Passwords does not match");
            return false;
        } else {
            etp2.setError(null);
            return true;
        }
    }

    private void createUser() {
        String email = ete.getText().toString();
        String pass = etp.getText().toString();
        String PersonName = etPersonName.getText().toString();

        if (!validateEmail(email) | !validatePersonName(PersonName) | !validatePassword(pass)) {
            return;
        } else {
                HashMap<String, Object> userInfoMap = new HashMap<>();
                userInfoMap.put("Password", pass);
                userInfoMap.put("Email", email);

            DatabaseReference _ref = FirebaseDatabase.getInstance().getReference("Customers");
            _ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.hasChild(PersonName)) {
                        etPersonName.setError("Username is already taken");
                        etPersonName.requestFocus();
                    } else {
                        FirebaseDatabase.getInstance().getReference().child("Customers").child(PersonName).updateChildren(userInfoMap);
                        _ref.removeEventListener(this);

                        Intent i = new Intent(MainActivity2Register.this, MainActivity3HomeScreen.class);

                        i.putExtra("PersonName", PersonName);
                        startActivity(i);

                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }

    }


    @Override
    public void onClick(View v) {
        if (v == btnChange) {
            dialog = new Dialog(this);//יצירת אובייקט דו-שיח
            dialog.setCancelable(true);//לא ניתן לבטל עם esc
            dialog.setContentView(R.layout.changepassword);//להשתמש בחלון xml custom_layout
            //ref to dialog widgets
            etPersonName2 = dialog.findViewById(R.id.etPersonName2);
            etp2=dialog.findViewById(R.id.etp2);
            btnLoginFR2 = dialog.findViewById(R.id.btnLoginFR2);
            etcp2=dialog.findViewById(R.id.etcp2);

            btnLoginFR2.setOnClickListener(this);
            dialog.show();
        }
        if (v==btnLoginFR2){
            String pass = etp2.getText().toString();
            String PersonName = etPersonName2.getText().toString();

            if (  !validatePersonName2(PersonName) | !validatePassword2(pass)) {
                return;
            } else {
                HashMap<String, Object> userInfoMap = new HashMap<>();
                userInfoMap.put("Password", pass);


                DatabaseReference _ref = FirebaseDatabase.getInstance().getReference("Customers");
                _ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if(snapshot.hasChild(PersonName)){
                            FirebaseDatabase.getInstance().getReference().child("Customers").child(PersonName).updateChildren(userInfoMap);
                            _ref.removeEventListener(this);

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
            dialog.dismiss();
            Toast.makeText(this,"Nice",Toast.LENGTH_LONG).show();
        }
        if (v==btnBack){
            Intent i = new Intent(MainActivity2Register.this, MainActivity.class);
            startActivity(i);
        }
    }
}