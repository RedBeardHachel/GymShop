package com.example.mygymstoreapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.MyViewHolder>{

    private Context context;
    private ArrayList<WheyProduct> productsList;
    private OnRecyclerViewClickListener listener;

    public UserListAdapter(Context context,ArrayList<WheyProduct> productsList){
        this.productsList=productsList;
        this.context=context;
    }

    public interface OnRecyclerViewClickListener
    {
        void OnItemClick(int position);
    }


    public void OnRecyclerViewClickListener(OnRecyclerViewClickListener listener)
    {
        this.listener = listener;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView name, price, weight, company,cosher,expirydate,amount;
        public MyViewHolder(@NonNull View itemView, OnRecyclerViewClickListener listener) {
            super(itemView);


            this.name = itemView.findViewById(R.id.tvName);
            this.price = itemView.findViewById(R.id.tvPrice);
            this.weight = itemView.findViewById(R.id.tvWeight);
            this.company = itemView.findViewById(R.id.tvCompany);
            this.cosher = itemView.findViewById(R.id.tvCosher);
            this.expirydate = itemView.findViewById(R.id.tvExpiryDate);
            this.amount=itemView.findViewById(R.id.tvAmount);

            itemView.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    if(listener != null && getAdapterPosition() != RecyclerView.NO_POSITION)
                    {
                        listener.OnItemClick(getAdapterPosition());
                    }
                }
            });
        }

    }


    @NonNull
    @Override
    public UserListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new MyViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull UserListAdapter.MyViewHolder holder, int position) {

         WheyProduct currProduct=productsList.get(position);
         holder.name.setText(currProduct.getName());
         holder.price.setText(currProduct.getPrice());
         holder.weight.setText(String.valueOf(currProduct.getWeight()));
         holder.company.setText(currProduct.getCompany());
         holder.cosher.setText(currProduct.getCosher());
         holder.expirydate.setText(currProduct.getExpirydate());
         holder.amount.setText(currProduct.getAmount());

    }

    @Override
    public int getItemCount() {

        return productsList.size();
    }


}
